#pragma once
// TOKENIZING MODULE HEADER
#ifndef _TOKENIZING_H_
#define _TOKENIZING_H_
#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 300
#include <stdio.h>
#include <string.h>
void tokenizing(void);
#endif