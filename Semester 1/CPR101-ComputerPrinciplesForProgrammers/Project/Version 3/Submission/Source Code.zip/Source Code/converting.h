// CONVERTING MODULE HEADER
#ifndef _CONVERTING_H_
#define _CONVERTING_H_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void converting(void);
#endif