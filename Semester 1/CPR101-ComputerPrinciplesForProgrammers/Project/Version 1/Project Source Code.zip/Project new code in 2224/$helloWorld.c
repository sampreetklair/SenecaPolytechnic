/*
helloWorld : the canonical test of any programming language thanks to K&R.
*/
#include <stdio.h>	// Standard Input/Output 
int main(void)		// mainline
{
	// console output as proof of compiler installation and operation
	printf("Hello, World!\n");     
	printf("This is a test for a command line (gcc) compiler.\n"); 
	return 0; 	
}
