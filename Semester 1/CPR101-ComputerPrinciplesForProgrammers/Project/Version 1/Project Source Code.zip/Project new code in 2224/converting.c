#include "converting.h"

void converting() {
/* Version 1 */
>> insert here


/* Version 2 */
>> insert here


/* Version 3 */
>> insert here


}
