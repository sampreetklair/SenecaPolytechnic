#include "manipulating.h"

void manipulating() {
/* Version 1 */
>> insert here


/* Version 2 */
>> insert here


/* Version 3 */
>> insert here


}